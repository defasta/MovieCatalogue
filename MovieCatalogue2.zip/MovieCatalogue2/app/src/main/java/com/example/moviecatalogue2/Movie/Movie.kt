package com.example.moviecatalogue2.Movie

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Movie(
    var photo: String? = null,
    var name: String? = null,
    var description: String? = null,
    var year: String? = null,
    var score: String? = null
) : Parcelable
