package com.example.moviecatalogue2.TvShow

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.moviecatalogue2.R
import kotlinx.android.synthetic.main.activity_tvshow_detail.*

class TvshowDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TVSHOW = "extra_tvshow"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tvshow_detail)
        val tvshow = intent.getParcelableExtra(EXTRA_TVSHOW) as TvShow

        val url = "https://image.tmdb.org/t/p/w342/${tvshow.photo}"
        Glide.with(this)
            .load(url)
            .into(img_photo)
        txt_name.text = tvshow.name
        txt_description.text = tvshow.description
        txt_year.text = tvshow.year
        txt_score.text = tvshow.score

    }
}
